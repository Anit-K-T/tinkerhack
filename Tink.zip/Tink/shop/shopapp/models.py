from django.db import models
class Store(models.Model):
    storename = models.CharField(max_length=20)
    location = models.CharField(max_length=20)

class Products(models.Model):
    stores = models.ForeignKey('Store',on_delete=models.CASCADE,default=None)
    name = models.CharField(max_length=20)
    brand = models.CharField(max_length=20)
